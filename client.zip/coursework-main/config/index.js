module.exports = {
  port: 8000,
  secret: "supersecret",
  expiresIn: 86400, // expires in 24 hours,
  isConsoleLog: true,
  isTestSetup: true,
}